<?php
$registered=0;
$userexists=0;
if($_SERVER['REQUEST_METHOD']=='POST'){
    include 'connection.php';
  $name=$_POST['name'];
  $mail=$_POST['mail'];
  $phone=$_POST['phone'];
  $pass=$_POST['pass'];
  $dob=$_POST['dob'];

    $sql="SELECT * FROM signup WHERE name='$name'";
    $result=mysqli_query($con,$sql);
    if($result){
        $num=mysqli_num_rows($result);
        if($num>0){
            $userexists=1;
        }
        else{
            $sql="INSERT INTO signup (name,mail,phone,pass,dob,interest) VALUES ('$name','$mail','$phone','$pass','$dob','$interest)";
            $result=mysqli_query($con,$sql);
            if($result){
                echo "Successful";
                $registered=1;
            }else{
                die(mysqli_error($con));
            }
        }
       
           
        }
    }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        header{
            text-align: center;
        }
        body {
            margin: 0;
            padding: 0;
            background-image: url('bg img.jpg');
            background-color: #000;
            background-size: cover;
            background-attachment: fixed; /* Fix background image */
            font-family: 'Palatino Linotype', 'Book Antiqua', Palatino, serif;
            color: white;
        }
        .form {
            justify-content: center;
      max-width: 500px;
      margin-left: 500px ;
      border: 4px dotted #69da0d; /* Adjusted border size and style */
      padding: 15px; /* Added padding */
    }
    .footer{
          text-align: center;
          color: greenyellow;
          width: 100%;
          background-color: rgba(255, 255, 255, 0.1);
    }
    legend{
        text-align: center;
        color: #69da0d;
    }
    .navbar{
        background-color: rgba(255, 255, 255, 0.1);
    }
    h1{
        color: #69da0d;
    }
    </style>
</head>
<body>
<header><h1>REGISTRATION</h1></header><br>
<div class="navbar"><nav class="navbar navbar-expand-sm sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="SAP.php">
            <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="SAP.php" target="_blank" style="color: #69da0d;">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php" target="_blank" style="color: #69da0d;">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="register.php" style="color: #69da0d;">Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="calc.php" target="_blank" style="color: #69da0d;">Calculator</a>
                </li>
            </ul>
        </div>
    </div>
</nav></div><br>
<div class="form">
<div class="container mt-3">
    <form>
        <fieldset>
            <legend>Registration Details</legend>
            <div class="form-floating mt-3 mb-3">
                <input type="text" class="form-control" id="Name" placeholder="Enter Name" name="name" required>
                <label for="name" style="color: #69da0d;">Name</label>
            </div>
            <div class="form-floating mt-3 mb-3">
                <input type="text" class="form-control" id="regno" placeholder="Enter register number" name="regno" required>
                <label for="regno" style="color: #69da0d;">Register Number</label>
            </div>
            <div class="form-floating mt-3 mb-3">
                <input type="text" class="form-control" id="password" placeholder="Enter password" name="password" required>
                <label for="pwd" style="color: #69da0d;">Password</label>
            </div>
            <div class="form-floating mt-3 mb-3">
                <input type="text" class="form-control" id="Year" placeholder="Enter Year" name="year" required>
                <label for="Year" style="color: #69da0d;">Year</label>
            </div>
            <div class="form-floating mt-3 mb-3">
                <input type="text" class="form-control" id="Department" placeholder="Enter Department" name="dept" required>
                <label for="Dept" style="color: #69da0d;">Department</label>
            </div>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-success">SUBMIT</button>
            </div>
            <br>
        </fieldset>
    </form>
</div>
</div><br><br>
<div class="footer">
<footer><div class="d-inline-flex p-3 ">
    <div class="p-2"><a href="https://web.whatsapp.com" data-bs-toggle="tooltip" data-bs-placement="top" title="Whatsapp"><img src="wp.jpg" alt="whatsapp" class="rounded-circle" width="50px" height="75px"></a>
     <a href="https://twitter.com" data-bs-toggle="tooltip" data-bs-placement="top" title="Twitter"><img src="twitter.jpg" alt="twitter" class="rounded-circle" width="50px" height="75px"></a></div>
    <div class="p-2">Contact us<br> Akash : 9080144598<br>Alwin : 7373705013 </div>
    <div class="p-2">Copyright 1999-2024 by Refsnes Data. All Rights Reserved</div>
  </div></footer></div>
</body>
</html>
