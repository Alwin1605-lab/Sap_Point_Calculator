<?PHP
$HOSTNAME='localhost';
$USERNAME='root';
$PASSWORD='';
$DATABASE='sapcalc';
$con=mysqli_connect($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE)
if($con){
    echo "connection successfull";
}
else{
    die(mysqli_connect($con));
}
?>