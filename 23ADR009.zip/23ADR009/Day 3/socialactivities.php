<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    h1{
        text-align: center;
    }
    footer{
        text-align: center;
    }
    body {
margin: 0;
padding: 0;
background-image: url('background img.jpg');
background-color: #000;
background-size: cover;
background-attachment: fixed; /* Fix background image */
font-family: 'Palatino Linotype', 'Book Antiqua', Palatino, serif;
color: white;
}
ul{
justify-content: center;
}
</style>
</head>
<body>
    <header><h1>SAP Calculator</h1></header>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="SAP.php">
            <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
          </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" href="SAP.php" target="_blank">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php" target="_blank">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php" target="_blank">Register</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="calc.php">Calculator</a>
              </li>
          </ul>
        </div>
        </div>
      </nav><br><br>
    <div class="Social_activity">
        <table class="table table-bordered table-hover">
            <tr>
                <td rowspan="2">Activity</td>
                <td colspan="4">Community services</td>
            </tr>
            <tr>
                <td>Activities such as Blood donation</td>
                <td>1 to 2 weeks (NSS/NCC Camps etc.)</td>
                <td>More than 2 weeks</td>
                <td>Max Points</td>
            </tr>
            <tr>
                <th>12.Social activity</th>
                <th>5/Activity</th>
                <th>30</th>
                <th>50</th>
                <th>50</th>
            </tr>
            <tr>
                <td>Count</td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
            </tr>
            <tr>
                <td>Student marks(count x marks)</td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
            </tr>
            <tr>
                <td>Class Advisor marks(count x marks)</td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
            </tr>
            <tr>
                <td>Proof page number</td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
                <td><input type="number" class="form-control"></td>
            </tr>
        </table><br>
        <p class="text-end">Class Advisor Signature</p>
    </div>
    <ul class="pagination">
      <li class="page-item"><a class="page-link" href="entrepreneurship.php">PREVIOUS</a></li>
      <li class="page-item"><a class="page-link" href="paperpresentation.php">NEXT</a></li>
      </ul>
</body>
</html>