<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Login Page</title>
    <style>
        h1{
            text-align: center;
        }
        footer{
            text-align: center;
        }
        body {
    margin: 0;
    padding: 0;
    background-image: url('background img.jpg');
    background-color: #000;
    background-size: cover;
    background-attachment: fixed; /* Fix background image */
    font-family: 'Palatino Linotype', 'Book Antiqua', Palatino, serif;
    color:#69da0d;
  }
  ul{
    justify-content: center;
  }
    </style>
</head>
<body background="background img.jpg">
    <header><h1>SAP Calculator</h1></header>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="SAP.php">
            <img src="logo.png" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
          </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" href="SAP.php" target="_blank">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php" target="_blank">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php" target="_blank">Register</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="calc.php">Calculator</a>
              </li>
          </ul>
        </div>
        </div>
      </nav>
    <div class="container mt-3">
    <div class="page-1">
        <div class="heading">
            <br>
            <br>
          <h4 class="text-center">KONGU ENGINEERING COLLEGE, PERUNDURAI, ERODE - 638060</h4>
          <br>
          <h4 class="text-center">DEPARTMENT OF ARTIFICAL INTELLIGENCE</h4>
          <h4 class="text-center">STUDENT ACTIVITY POINTS INDEX</h4>
        </div><br>
        <div class="student_detial">
            <table class="table table-bordered table-hover">
                <colgroup>
                    <col style="width: 300px;">
                    <col style="width: 30px;">
                </colgroup>
                <tr>
                    <td>Student Name</td>
                    <td>:</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
                <tr>
                    <td>Roll Number</td>
                    <td>:</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
                <tr>
                    <td>Year</td>
                    <td>:</td>
                    <td><input class="form-control" list="browsers" name="browser" id="browser">
                      <datalist id="browsers">
                        <option value="I">
                        <option value="II">
                        <option value="III">
                        <option value="IV">
                      </datalist></td>
                </tr>
                <tr>
                    <td>Section</td>
                    <td>:</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
                <tr>
                    <td>Semester</td>
                    <td>:</td>
                    <td><input class="form-control" list="semesters" name="semester" id="semester">
                      <datalist id="semesters">
                        <option value="I">
                        <option value="II">
                        <option value="III">
                        <option value="IV">
                        <option value="V">
                        <option value="VI">
                        <option value="VII">
                        <option value="VII">
                      </datalist></td>
                </tr>
                <tr>
                    <td>Academic Year</td>
                    <td>:</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
                <tr>
                    <td>Mentor Name</td>
                    <td>:</td>
                    <td><input type="text" class="form-control"></td>
                </tr>
            </table>
        </div>
        <h5 style="text-align: start;">Reference:</h3>
        <div class="reference">
            <table class="table table-bordered table-hover">
                <tr>
                    <td>Activity points earned in a semested</td>
                    <td>BE/BTech <br>and MSc</td>
                    <td>80 or More</td>
                    <td>50-79</td>
                    <td>20-49</td>
                    <td>Below 20</td>
                </tr>
                <tr>
                    <td colspan="2">Marks earned per coursein the semester</td>
                    <td>3</td>
                    <td>2</td>
                    <td>1</td>
                    <td>0</td>
                </tr>
            </table>
        </div>
        <br>
        <div class="Evaluation">
            <table class="table table-bordered table-hover">
                <tr>
                    <th rowspan="2">Evaluation</th>
                    <td colspan="3">Evalution done by</td>
                </tr>
                <tr>
                    <th>Students</th>
                    <th>Class Advisor</th>
                    <th rowspan="4"></th>
                </tr>
                <tr>
                    <td>Did All the proofs are verified?</td>
                    <td><input class="form-check-input" type="checkbox" id="check1" name="option1" value="something">
                      <label class="form-check-label">YES</label>
                      <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something">
                      <label class="form-check-label">NO</label></td>
                    <td><input class="form-check-input" type="checkbox" id="check1" name="option1" value="something">
                      <label class="form-check-label">YES</label>
                      <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something">
                      <label class="form-check-label">NO</label></td>
                </tr>
                <tr>
                    <td>Maximum Points <br> Earned</td>
                    <td><input type="number" class="form-control"></td>
                    <td><input type="number" class="form-control"></td>
                </tr>
                <tr>
                    <td>Other Marks for Internal(Max.5)</td>
                    <td><input type="number" class="form-range" min="0" max="5"></td>
                    <td><input type="number" class="form-range" min="0" max="5"></td>
                </tr>
                <tr>
                    <th>Signature with date</th>
                    <td></td>
                    <td></td>
                    <th rowspan="5">Signature of class advisor with date</th>
                </tr>
            </table>
        </div>
        <ul class="pagination">
          <li class="page-item"><a class="page-link" href="paperpresentation.php">NEXT</a></li>
        </ul>
</body>
</html>